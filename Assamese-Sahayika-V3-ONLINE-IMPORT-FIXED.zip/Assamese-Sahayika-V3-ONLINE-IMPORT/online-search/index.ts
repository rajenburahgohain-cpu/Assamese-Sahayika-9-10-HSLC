// Supabase Edge Function: online-search
// Free/default mode: DuckDuckGo Instant Answer API + Wikipedia search API.
// For broader web search, replace/add a paid/approved provider in this function.
import { serve } from "https://deno.land/std@0.224.0/http/server.ts";

const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

function json(data: unknown, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { ...cors, "Content-Type": "application/json; charset=utf-8" },
  });
}

serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  if (req.method !== "POST") return json({ error: "POST required" }, 405);

  try {
    const body = await req.json();
    const query = String(body?.query || "").trim();
    const context = String(body?.context || "").trim();
    if (!query) return json({ error: "query is required" }, 400);

    const q = context ? `${context} ${query}` : query;
    const results: Array<{title:string; snippet:string; url:string}> = [];

    // DuckDuckGo Instant Answer API (no API key required).
    try {
      const ddgUrl = `https://api.duckduckgo.com/?q=${encodeURIComponent(q)}&format=json&no_html=1&skip_disambig=1`;
      const r = await fetch(ddgUrl, { headers: { "User-Agent": "Assamese-Sahayika/1.0" } });
      if (r.ok) {
        const d = await r.json();
        if (d.AbstractText) {
          results.push({
            title: d.Heading || "DuckDuckGo result",
            snippet: d.AbstractText,
            url: d.AbstractURL || "https://duckduckgo.com/?q=" + encodeURIComponent(q),
          });
        }
        for (const t of (d.RelatedTopics || [])) {
          if (t?.Text) {
            results.push({ title: t.Text.slice(0, 100), snippet: t.Text, url: t.FirstURL || "" });
          }
          if (results.length >= 5) break;
        }
      }
    } catch (_) {}

    // Wikipedia search gives useful textbook-topic references without a key.
    try {
      const wikiUrl = `https://as.wikipedia.org/w/api.php?action=query&list=search&srsearch=${encodeURIComponent(q)}&srlimit=5&format=json&origin=*`;
      const r = await fetch(wikiUrl, { headers: { "User-Agent": "Assamese-Sahayika/1.0" } });
      if (r.ok) {
        const d = await r.json();
        for (const x of (d?.query?.search || [])) {
          const title = String(x.title || "");
          const snippet = String(x.snippet || "").replace(/<[^>]+>/g, "");
          results.push({
            title: "অসমীয়া ৱিকিপিডিয়া — " + title,
            snippet,
            url: `https://as.wikipedia.org/wiki/${encodeURIComponent(title.replace(/ /g, "_"))}`,
          });
          if (results.length >= 8) break;
        }
      }
    } catch (_) {}

    return json({ ok: true, query: q, results: results.slice(0, 8) });
  } catch (e) {
    return json({ ok: false, error: String(e?.message || e) }, 500);
  }
});
