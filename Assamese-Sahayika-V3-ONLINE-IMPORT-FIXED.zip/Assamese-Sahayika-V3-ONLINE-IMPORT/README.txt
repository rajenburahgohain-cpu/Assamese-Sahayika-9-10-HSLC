ASSAMESE SAHAYIKA V3 - ONLINE QUESTION IMPORT

1. Replace the GitHub Pages index.html with the included index.html.
2. Deploy the included online-search/index.ts as the Supabase Edge Function named: online-search
3. Open Admin Panel and login.
4. In Online Question Collector, enter a search query and select the lesson.
5. Search online. Review a result.
6. Click "এই ফলাফল পাঠৰ প্ৰশ্নোত্তৰ হিচাপে লওক".
7. The result is copied into the normal Question/Answer form with the selected lesson and source URL.
8. Review/edit the answer, then click Save.

IMPORTANT:
- Online results are NOT automatically saved to students' database.
- Admin must review and explicitly Save a selected result.
- This keeps online content under admin control.
- The online-search function uses DuckDuckGo Instant Answer API and Assamese Wikipedia search. For broader web search, add an approved search provider in the Edge Function.
